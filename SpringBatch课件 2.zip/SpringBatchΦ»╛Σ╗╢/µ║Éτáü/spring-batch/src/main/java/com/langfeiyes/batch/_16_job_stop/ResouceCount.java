package com.langfeiyes.batch._16_job_stop;

public class ResouceCount {
    public static int totalCount = 100;  //总数
    public static int  readCount = 0;    //读取数
}