package com.langfeiyes.batch._17_job_stop_sign;

public class ResouceCount {
    public static int totalCount = 100;  //总数
    public static int  readCount = 0;    //读取数
}