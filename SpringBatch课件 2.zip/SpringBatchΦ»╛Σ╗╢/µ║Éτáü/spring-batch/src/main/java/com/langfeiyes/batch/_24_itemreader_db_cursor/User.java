package com.langfeiyes.batch._24_itemreader_db_cursor;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class User {
    private Long id;
    private String name;
    private int age;
}