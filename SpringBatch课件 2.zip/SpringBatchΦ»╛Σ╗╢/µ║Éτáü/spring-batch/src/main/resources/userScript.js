item.setName(item.getName().toUpperCase());
item;