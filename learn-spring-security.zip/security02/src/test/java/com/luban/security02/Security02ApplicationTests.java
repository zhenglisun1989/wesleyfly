package com.luban.security02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
