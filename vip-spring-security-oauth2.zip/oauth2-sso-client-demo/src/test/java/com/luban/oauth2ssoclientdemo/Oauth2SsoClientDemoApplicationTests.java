package com.luban.oauth2ssoclientdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2SsoClientDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
