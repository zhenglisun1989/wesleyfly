package com.luban.gatewayserver.common;

/**
 * 常量类
 *
 */
public class MDA {

    public static final String clientId = "gateway-server";

    public static final String clientSecret = "123123";

    public static final String checkTokenUrl = "http://auth-server/oauth/check_token";


}
